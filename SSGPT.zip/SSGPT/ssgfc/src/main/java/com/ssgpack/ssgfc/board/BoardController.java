package com.ssgpack.ssgfc.board;


import org.springframework.stereotype.Controller;


@Controller
public class BoardController {
 
	

}
