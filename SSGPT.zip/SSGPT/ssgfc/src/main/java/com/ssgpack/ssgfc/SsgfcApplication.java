package com.ssgpack.ssgfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsgfcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsgfcApplication.class, args);
	}

}
