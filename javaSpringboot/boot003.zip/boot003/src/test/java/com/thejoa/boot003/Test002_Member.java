package com.thejoa.boot003;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test002_Member {

	@Test
	public void insert() {
	}

}
