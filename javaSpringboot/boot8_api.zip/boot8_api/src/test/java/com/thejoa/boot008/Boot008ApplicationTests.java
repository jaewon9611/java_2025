package com.thejoa.boot008;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot008ApplicationTests {

	@Test
	void contextLoads() {
	}

}
