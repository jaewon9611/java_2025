//package repeat0310;
//class Score {
//	private
//}
//
//
//
//
//
//public class Repeat005 {
//	public static void main(String[] args) {
//		Score[] std = new Score[3];
//		std[0] = new Score("아이언맨",100,100,100);
//		std[1] = new Score("헐크",90,60,80);
//		std[2] = new Score("블랙팬서",20,60,90);
//		
//		ScoreProcess process = new ScoreProcess();
//		process.process_avg(std);
//		process.process.prass(std);
//		
//		ScorePrint print = new ScorePrint();
//		print.show(std);
//	}
//}
//1. Score, ScoreProcess,ScorePrint 클래스와 ClassArr004 클래스
//패키지를 분리하시오.
// 클래스들의 옵션은 다음과 같다. 멤버필드를 private 로 설정하시오
//3. 다음과 같이 출력되도록 main을 채우시오.
//package part002;

