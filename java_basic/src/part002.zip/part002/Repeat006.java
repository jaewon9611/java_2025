package part002;

public class Repeat006 {
	public static void main(String[] args) {
		
	}
}
/*
Q1) 클래스를 상속하는 이유를 적으시오.
Q2) 상속의 형식을 적으시오.
Q3) ##을 채우고 출력되는 결과를 적으시오.
class A1 [##1] {// Object를 상속받는다
int a;
public A1() {super();}
public A1(int a) {super(); this.a=a;}
}
class B1 [##2] A1 { // A1을 상속받는다
int b;
public B1(){super();}
public B1(int b){this.b=b;}
public B1(int a , int b){super(a); this.b=b;}
}

*/