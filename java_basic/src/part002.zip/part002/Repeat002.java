package part002;

class A{
	int a;					// 인스턴스 변수
	static String company;  // 클래스 변수
	void method() {int a;}  // 지역 변수
}

public class Repeat002 {

}
//1. 클래스변수(static변수),인스턴스변수(new:heap),지역변수(stack)로 구분하고
//2. 오류날만한 코드를 적으시오